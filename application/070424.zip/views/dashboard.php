<style>
.card-body {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 2.0rem 1.25rem;
}
</style>
<div class="page-content">
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box d-sm-flex align-items-center justify-content-between">
					<h4 class="mb-sm-0">Dashboard</h4>

					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="javascript: void(0);">Etihad Muslim Community Welfare Society</a></li>
							<li class="breadcrumb-item active">Dashboard</li>
						</ol>
					</div>
				</div>  
			</div>
		</div>
		<!-- end page title -->  
		<div class="row">
			<div class="col-md-4">
				<div class="card">
					<div  style="cursor:pointer" onclick='window.location.href="<?php echo base_url(); ?>Dashboard/form"' class="card-body">
						<div class="d-flex text-muted">
							<div class="flex-shrink-0  me-3 align-self-center">
								<div class="avatar-sm">
									<div class="avatar-title bg-light rounded-circle text-primary font-size-20">
										<img src="<?php echo base_url();?>assets/img/form.jpg">
									</div>
								</div>
							</div>
							<div class="flex-grow-1 overflow-hidden">
								<p class="mb-1">Total Forms</p>
								<h5 class="mb-3"><?php echo $totalforms; ?></h5>  
							</div>
						</div>
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
			</div>
			<div class="col-md-4">
				<div class="card">
					<div style="cursor:pointer" onclick='window.location.href="<?php echo base_url(); ?>Dashboard/havingadhar"' class="card-body">
						<div class="d-flex text-muted">
							<div class="flex-shrink-0  me-3 align-self-center">
								<div class="avatar-sm">
									<div class="avatar-title bg-light rounded-circle text-primary font-size-20">
										<img src="<?php echo base_url();?>assets/img/aadhaar.png">
									</div>
								</div>
							</div>
							<div class="flex-grow-1 overflow-hidden">
								<p class="mb-1">People Having Aadhar Card</p>
								<h5 class="mb-3"><?php echo $haveaadhar; ?></h5>
								
							</div>
						</div>
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
			</div>
			<div class="col-md-4">
				<div class="card">
					<div style="cursor:pointer" onclick='window.location.href="<?php echo base_url(); ?>Dashboard/nothavingadhar"' class="card-body">
						<div class="d-flex text-muted">
							<div class="flex-shrink-0  me-3 align-self-center">
								<div class="avatar-sm">
									<div class="avatar-title bg-light rounded-circle text-primary font-size-20">
										<img src="<?php echo base_url();?>assets/img/aadhaar.png">
									</div>
								</div>
							</div>
							<div class="flex-grow-1 overflow-hidden">
								<p class="mb-1">People NOT Having Aadhar Card</p>
								<h5 class="mb-3" id="shopstotalsale"><?php echo $nothaveaadhar?></h5>
								
							</div>
						</div>
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
			</div>
			<div class="col-sm-4">
				<div class="card">
					<div style="cursor:pointer" onclick='window.location.href="<?php echo base_url(); ?>Dashboard/havingvoter"' class="card-body">
						<div class="d-flex text-muted">
							<div class="flex-shrink-0  me-3 align-self-center">
								<div class="avatar-sm">
									<div class="avatar-title bg-light rounded-circle text-primary font-size-20">
										<img src="<?php echo base_url();?>assets/img/voter.jpg">
									</div>
								</div>
							</div>
							<div class="flex-grow-1 overflow-hidden">
								<p class="mb-1">People Having Voter Card</p>
								<h5 class="mb-3" id="shopstotalpaid"><?=$havevoter?></h5>
								
							</div>
						</div>
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
			</div>
			<div class="col-sm-4">
				<div class="card">
					<div style="cursor:pointer" onclick='window.location.href="<?php echo base_url(); ?>Dashboard/nothavingvoter"' class="card-body">
						<div class="d-flex text-muted">
							<div class="flex-shrink-0  me-3 align-self-center">
								<div class="avatar-sm">
									<div class="avatar-title bg-light rounded-circle text-primary font-size-20">
										<img src="<?php echo base_url();?>assets/img/voter.jpg">
									</div>
								</div>
							</div>
							<div class="flex-grow-1 overflow-hidden">
								<p class="mb-1">People Not Having Voter Card</p>
								<h5 class="mb-3" id="shopstotaldue"><?=$nothavevoter?></h5>
								
							</div>
						</div>
					</div>
					<!-- end card-body -->
				</div>
				<!-- end card -->
			</div>
		</div>
		<!-- end row -->
	</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->      


