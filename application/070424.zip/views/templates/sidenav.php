<!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu" style="display:<?php if(strpos(strtolower($_SERVER["HTTP_USER_AGENT"]), "mobile") =='' ){ echo "block"; }else{ echo "none"; } ?>">
               <div data-simplebar class="h-100">
                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">                 
                            <div class="components-nav">
                            <li class="menu-title">
							<div class="menu-logo">
								<img src="<?php echo base_url(); ?>assets/img/alq_logo.png" alt="Logo">
								<span>Welcome emcvizag</span>
							</div>
							</li>
                            <li class="forms-nav">
                               <a href="<?php echo base_url(); ?>Dashboard/getdashboard" class="waves-effect">
                                    <i class="fas fa-database"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>
                            <li class="forms-nav">
                                <a href="<?php echo base_url(); ?>Dashboard/formentry" class="waves-effect">
                                    <i class="fas fa-edit"></i>
                                    <span>Form Entry</span>
                                </a>
                            </li>
                            <li class="forms-nav">
                                <a href="<?php echo base_url(); ?>Dashboard/createusers" class="waves-effect">
                                    <i class="fas fa-user"></i>
                                    <span>Create Users</span>
                                </a>
                            </li>
                            <li class="forms-nav">
                                <a href="<?php echo base_url(); ?>Dashboard/allForms" class="waves-effect">
                                    <i class="fas fa-edit"></i>
                                    <span>Edit Form</span>
                                </a>
                            </li>               
                            <li class="forms-nav">
                                <a href="<?php echo base_url(); ?>/Welcome/logout" class="waves-effect">
                                    <i class="ri-shut-down-line align-middle me-1 text-danger"></i>
                                    <span>Logout</span>
                                </a>
                            </li>
                               
                        </div>
                        </ul>                    
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
            