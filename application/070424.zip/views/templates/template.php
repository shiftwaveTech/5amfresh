<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="Etihad Muslim Community Welfare Society" name="description" />
        <meta content="Themesdesign" name="author" />

        {_meta}
		<!-- page title specific to the page -->
        <title>{title}</title>
   
            <!-- js file -->
       <!--  <link rel="shortcut icon" href="<?php //echo base_url(); ?>assets/img/favicon.ico">-->
        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/favicon.png">
        <!-- Bootstrap Css -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    
        <link href="<?php echo base_url(); ?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome Css -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />

        <!-- Icons Css -->
        <link href="<?php echo base_url(); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo base_url(); ?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/nav-styles.css">
        <link href="<?php echo base_url(); ?>assets/libs/jqvmap/jqvmap.min.css"/>   
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
        
        <!-- pagination -->
		
		<link href="<?php echo base_url(); ?>assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
	   <link href="<?php echo base_url(); ?>assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
	   <link href="<?php echo base_url(); ?>assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

         
     {_styles}
        
    </head>
     <body data-sidebar="colored">    
       <!-- end header-wrapper -->     
	   <div id="layout-wrapper">
	      {header}
          <div class="main-content">
	      {content}
	   </div>
       {footer}
	   </div>        
    </body>
</html>

		<script src="<?php echo base_url(); ?>assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/libs/node-waves/waves.min.js"></script>
		
		<script src="<?php echo base_url(); ?>assets/js/app.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/board.js"></script>
		
		   <!-- Sweet Alerts js -->
        <script src="<?php echo base_url(); ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

        <!-- Sweet alert init js-->
        <script src="<?php echo base_url(); ?>assets/js/pages/sweet-alerts.init.js"></script>

        <!-- jquery.vectormap map -->
        <script src="<?php echo base_url(); ?>assets/libs/jqvmap/jquery.vmap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/libs/jqvmap/maps/jquery.vmap.usa.js"></script> 
		
        <script src="<?php echo base_url(); ?>assets/js/app-js/login.js"></script>     

        <script src="<?php echo base_url(); ?>assets/js/app-js/common.js"></script>
		
		<script src="<?php echo base_url(); ?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/libs/jszip/jszip.min.js"></script>
		
		
		 <!-- pagination -->
		 <script src="<?php echo base_url(); ?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
		 <script src="<?php echo base_url(); ?>assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
		 <script src="<?php echo base_url(); ?>assets/js/pages/datatables.init.js"></script>
		 
		
		
		

    {_scripts}  
