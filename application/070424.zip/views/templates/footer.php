<footer class="footer" style="background-color: #24BB43;color:white">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<script>document.write(new Date().getFullYear())</script> © Shiftwave
			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
				All rights reserved. Powered by <a style="color:white" href="https://shiftwave.com">Shiftwave</a>
				</div>
			</div>
		</div>
	</div>
</footer>