<style>
body{
    background: url(<?php echo base_url();?>assets/img/1.jpg) #1e771a !important; 
    background-size: cover !important;
    background-position: center !important;
	}
.main-content {
	margin-left: 0px !important;
}
</style>
<div class="bg-overlay"></div>
<div class="account-pages my-4 pt-5" style="overflow-x: none;">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-5">
				<div class="card">
					<div class="card-body p-4">
						<div class="">
							<div class="text-center">
								<a href="http://localhost/emc/" class="">
									<img src="assets/img/emc-logo.png" alt="" height="80" class="auth-logo logo-dark mx-auto">                                          
								</a>
							</div>
							<!-- end row -->                                    
							<p class="text-center">Sign in to Etihad Muslim Community Welfare Society.</p>                                  
								<div class="row">
									<div class="col-md-12">
										<div class="mb-4">                                                 
											<select class="form-control" name="account_type" id="account_type">
												<option value="">Select Type</option>   
												<option value="5">Admin</option> 
												<option value="4">User</option> 
											</select>
										</div>
										<div class="mb-4">
											<label class="form-label" for="username">Username</label>
											<input type="text" class="form-control" name="username" id="username" placeholder="Enter username">
										</div>
										<div class="mb-4">
											<label class="form-label" for="userpassword">Password</label>
											<input type="password" class="form-control" name="user_password" id="user_password" placeholder="Enter password">
										</div>
									   
										<div class="d-grid mt-4">
											<button style="background-color:#24BB43;color:white;" class="btn waves-effect waves-light" type="submit" name="submit" id="submit" onclick="return signInValidation();">Log In</button>
										</div>
									</div>
								</div>                                
						</div>
					</div>
				</div>
				<div class="text-center">                           
					<p class="text-white-50">© <script>document.write(new Date().getFullYear())</script> Etihad Muslim Community Welfare Society. Developed by Shiftwave</p>
				</div>
			</div>
		</div>
		<!-- end row -->
	</div>
</div>
<!-- end Account pages -->


           