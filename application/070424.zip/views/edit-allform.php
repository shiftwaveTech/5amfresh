<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <!-- Start -->
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Default wizard -->
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Add New Entry
                            </div>
                            <div class="panel-body">
                                <div class="form-horizontal" >
                                    <input type="hidden" name="userform" value="<?php echo $username ?>" class="form-control" id="inputStandard">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-2 control-label">Form No.</label>
                                            <div class="col-lg-1">
                                                <input type="text" name="number" class="form-control" required id="inputStandard" value="<?=$userdata->application?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-2 control-label">Ward No.</label>
                                            <div class="col-lg-1">
                                                <input type="text" name="ward" class="form-control" id="inputStandard" required maxlength="5" value=<?=$userdata['']?>>
                                            </div>
                                            <label for="inputStandard" class="col-lg-4 control-label">Aadhar Card No.</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="adh" class="form-control" id="inputStandard" maxlength="12">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <h2 align="center" style="margin-bottom:2px">Etihad Muslim Community Welfare Society</h2>
                                                <br>
                                                <p align="center" style="margin-top:2px; font-family:arial">D.No.49-55-1B,Akkayapalem,Port Stadium,Near Central Bank,Visakhaptnam-530016.<br> Tel: 0891-2710063, Cell : 8374620063. E-mail:emcvizag@gmail.com </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Full Name</label>
                                            <div class="col-lg-5">
                                                <input type="text" name="fullname"  class="form-control" id="inputStandard">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Contact No</label>
                                            <div class="col-lg-3">
                                                <input type="text" maxlength="13" name="contact1"  class="form-control" id="inputStandard">
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Voter card No.</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="votercard" class="form-control" id="inputStandard" maxlength="10">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard"  class="col-lg-3 control-label">Address</label>
                                            <div class="col-lg-5">
                                                <textarea name="address"  cols="6" rows="4"  class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Date of Birth</label>
                                            <div class="col-lg-3">
                                                <input type="date" name="dateofbirth"  class="form-control" id="inputStandard">
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Gender</label>
                                            <div class="col-lg-3">
                                                <select id="accounttype" class="form-control" name="gen" onblur="validateSelect(name)" >
                                                    <option value="">Select</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Marital Status</label>
                                            <div class="col-lg-3">
                                                <select id="accounttype" class="form-control"    name="marital_status" onblur="validateSelect(name)"  >
                                                    <option value="">Select</option>
                                                    <option value="Married">Married</option>
                                                    <option value="Unmarried">Unmarried</option>
                                                    <option value="Divorced">Divorced</option>
                                                </select>
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Educational Qualification</label>
                                            <div class="col-lg-3">
                                                <select id="accounttype" class="form-control"   name="qualification" onblur="validateSelect(name)"  >
                                                    <option value="">Select</option>
                                                    <option value="Primary Education">Primary Education</option>
                                                    <option value="Secondary Education">Secondary Education</option>
                                                    <option value="SSC">SSC</option>
                                                    <option value="Inter">Inter</option>
                                                    <option value="Urdhu">Urdhu</option>
                                                    <option value="Arrabbi">Arrabbi</option>
                                                    <option value="Graduation">Graduation</option>
                                                    <option value="Post Graduation">Post Graduation</option>
                                                    <option value="Under Graduation">Under Graduation</option>
                                                    <option value="Un Education">Un Education</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Occupation</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="occ"  class="form-control" id="inputStandard">
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Annual Income</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="monthlyincome"  class="form-control" id="inputStandard">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Associated with Masjid</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="associated" value="<?php echo $val;?>" class="form-control" id="name">
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Residence</label>
                                            <div class="col-lg-3">
                                                <select id="accounttype" class="form-control"    name="residence" onblur="validateSelect(name)">
                                                    <option value="">Select</option>
                                                    <option value="Own">Own</option>
                                                    <option value="Rental">Rental</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div id="displa
                                        y"></div>
                                        <?php
                                            if(isset($_POST['submit']))
                                            {
                                                if(!empty($_POST['name']))
                                                {
                                                    $name=$_POST['name'];
                                                    $query3=mysqli_query($mysqli, "SELECT * FROM mosque WHERE name LIKE '%$name%'");
                                                    while($query4=mysqli_fetch_array($query3))
                                                    {
                                                        echo "<div id='box'>";
                                                        echo "<b>".$query4['name']."</b>";
                                                        echo "<div id='clear'></div>";
                                                        //echo $query4['descr'];
                                                        echo "</div>";
                                                    }
                                                }
                                                else
                                                {
                                                    echo "No Results";
                                                }
                                            }
                                        ?>
                                    </div>								
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="inputStandard" class="col-lg-3 control-label">Ration Card No.</label>
                                            <div class="col-lg-3">
                                                <input type="text" name="ration" class="form-control" id="inputStandard">
                                            </div>
                                            <label for="inputStandard" class="col-lg-2 control-label">Ration Card Type</label>
                                            <div class="col-lg-3">
                                                <select id="accounttype" class="form-control"   name="rationtype" onblur="validateSelect(name)"  >
                                                    <option value="">Select</option>
                                                    <option value="White">White</option>
                                                    <option value="Pink">Pink</option>
                                                    <option value="AAY">AAY</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="panel" id="spy2">
                                            <div class="panel-heading">
                                                <span class="panel-title">
                                                <span class="glyphicons glyphicons-table"></span>Dependants</span>
                                                <div class="pull-right">
                                                    <input type="button" class="btn  btn-primary btn-block" value="Add" onClick="changeIt()">
                                                </div>
                                            </div>
                                            <div class="panel-body pn">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Relationship</th>
                                                            <th>Gender</th>
                                                            <th>Age</th>
                                                            <th>Education</th>
                                                            <th>Occupation</th>
                                                            <th>Aadhaar No</th>
                                                            <th>VoterID No</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="my_div">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row" align="center" style="margin-left:30px">
                                            <div class="col-xs-3">
                                                <input type="checkbox" name="tick" value="1" required>Click the tick box to submit the Form
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row" align="center" style="margin-left:80px">
                                            <div class="col-xs-2">
                                                <!--   <button  type="submit" class="btn  btn-primary btn-block"  name="submit">submit</button> -->
                                                <input type="submit" name="submit" value="submit" class="btn  btn-primary btn-block">
                                            </div>
                                            <div class="col-xs-2">
                                                <input type="reset" name="reset" value="Reset" class="btn  btn-primary btn-block">
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End -->
            </div>
        </div>
    </div>
</div>
                