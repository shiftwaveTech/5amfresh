<div class="page-content">
    <div class="container-fluid">
        <div class="row">        
            <div class="col-12">
            <div class="card">
				<div class="card-body"> 
				<form>
					<div class="col-md-4 mb-3">								
						<div class="panel-heading">
							Add New User
						</div>  
					</div>
					<div class="col-md-4 mb-3 offset-md-2">							
						<input type="text" class="form-control" id="username" placeholder="Enter Username"> 
					</div>
					<div class="col-md-4 mb-3 offset-md-2">								
					  <input type="password" class="form-control" id="user_password" placeholder="Enter Password">
				    </div>	
					<div class="col-md-4 mb-3 offset-md-2 text-center"> 
						<button class="btn create-formbutton mr-2" type="button" name="submit" id="submit" onclick="signInValidation();">Submit</button>
						    <button class="btn create-formbutton btn-block" type="reset">Reset</button>
					</div>
				</form>
				</div>
			</div>
			</div>
		</div>		
		<div class="row"> 
			<div class="col-12">
				<div class="card">
					<div class="card-body">
							<table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
								<thead>
									<tr role="row">
										<th class="single-line">S.No</th>
										<th class="single-line">Username</th>
										<th class="single-line">Total Forms Posted</th>
										<th class="single-line">Today Posted Forms</th>
										<th class="single-line">Password</th>
										<th class="single-line">Manage</th>
									</tr>
								</thead>

								<tbody id="receipt_body">
									<?php 
										$Sno = 1; 
										foreach ($userData as $row) {
											$username = $row->username;
											$userid = $row->id;
										?>
										<tr>
											<td class="sorting_1 dtr-control"><?= $Sno++ ?></td>
											<td class="shopnames"><?= $row->username ?></td>
											<td><?= $totalForms[$username] ?></td>
											<td><?= $todayForms[$username] ?></td>
											<td><?= $row->password ?></td>
											<td>
												<button type="button" onclick="deleteUSer(<?php echo $userid?>)" class="btn btn-outline-success btn-sm">Delete</button>
											</td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
				</div>			
			</div>		
		</div>
	</div>
</div>
                
              
  