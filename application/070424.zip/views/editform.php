<div class="page-content">
    <div class="container-fluid">
       <!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box d-sm-flex align-items-center justify-content-between">
					<h4 class="mb-sm-0">Total List of Families</h4>

					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="javascript: void(0);">Etihad Muslim Community Welfare Society</a></li>
							<li class="breadcrumb-item active">Total List of Families
							</li>
						</ol>
					</div>
				</div>  
			</div>
		</div>
		<!-- end page title -->  
        <div class="row">
		<div class="card">
		  <div class="card-body">
            <div class="col-12">
            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
                <thead>
                    <tr role="row">
                        <th>S.No</th>                                                
                        <th>Ward No</th>
                        <th>Name</th>
                        <th>Occupation</th>                                                
                        <th>Aadhar Card No.</th>                                                
                        <th>Voter Card</th> 
                        <th>Contuct Number</th> 
                        <th>Manage</th> 
                    </tr>
                </thead>
                <tbody id="receipt_body">
                    <?php 
                        $Sno = 1; 
                        foreach ($totalfamilies as $row) {
                            $username = $row->name;
                            $userid = $row->id;
                        ?>
                        <tr>
                            <td><?=$Sno++ ?></td>
                            <td><?=$row->ward ?></td>											
                            <td><?=$row->name ?></td>											
                            <td><?=$row->occupation ?></td>											
                            <td><?=$row->adhar ?></td>											
                            <td><?=$row->voterid ?></td>
                            <td><?=$row->contact ?></td>
                            <td><button type="button" onclick="window.location.href='<?php echo base_url();?>Dashboard/editAllform/<?php echo $userid; ?>'" class="btn btn-outline-success btn-sm">Edit</button></td>
                        </tr>
                        <?php } ?>
                </tbody>
                </table>
				</div>
				</div>
            </div>
        </div>
    </div>
</div>