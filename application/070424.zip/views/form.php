<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>S.No</th>                                                
                        <th>Ward No</th>
                        <th>Name</th>
                        <th>Occupation</th>                                                
                        <th>Aadhar Card No.</th>                                                
                        <th>Voter Card</th> 
                        <th>Contuct Number</th> 
                        <th>Manage</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $Sno = 1; 
                        foreach ($forms as $row) {
                            $username = $row->name;
                            $userid = $row->id;
                        ?>
                        <tr>
                            <td><?=$Sno++ ?></td>
                            <td><?=$row->ward ?></td>											
                            <td><?=$row->name ?></td>											
                            <td><?=$row->occupation ?></td>											
                            <td><?=$row->adhar ?></td>											
                            <td><?=$row->voterid ?></td>
                            <td><?=$row->contact ?></td>
                            <td><button type="button" onclick="editfamilydetail(<?php echo $userid ?>)" class="btn btn-outline-success btn-sm">Edit</button></td>
                        </tr>
                        <?php } ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>